javac -g -cp . *.java
